PDF Converter - All Tools

Minimal Android app (Kotlin) that converts selected images into a single PDF file.
Includes basic AdMob integration (banner, interstitial, rewarded).

How to build:
1. Clone or upload this project into your GitHub repo.
2. Open the repo in Ona.dev or Android Studio.
3. Run: ./gradlew assembleDebug   (or use Android Studio Build > Build Bundle/APK)
4. Install app-debug.apk on device for testing.

Ad Units included (replace with yours if needed):
- Banner: ca-app-pub-6274254207306230/5673941265
- Interstitial: ca-app-pub-6274254207306230/4241332295
- Rewarded: ca-app-pub-6274254207306230/9780707239
