package com.myapp1718.pdfconverter

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private val pickedUris = mutableListOf<Uri>()
    private lateinit var statusTv: TextView
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null

    // Activity result for picking images
    private val pickImagesLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            pickedUris.clear()
            if (!uris.isNullOrEmpty()) {
                pickedUris.addAll(uris)
                statusTv.text = "Picked ${'$'}{pickedUris.size} image(s)"
                Toast.makeText(this, "Picked ${'$'}{pickedUris.size} image(s)", Toast.LENGTH_SHORT).show()
            } else {
                statusTv.text = "No images picked"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusTv = findViewById(R.id.tv_status)
        val pickBtn = findViewById<Button>(R.id.btn_pick)
        val convertBtn = findViewById<Button>(R.id.btn_convert)

        pickBtn.setOnClickListener {
            pickImagesLauncher.launch(arrayOf("image/*"))
        }

        convertBtn.setOnClickListener {
            if (pickedUris.isEmpty()) {
                Toast.makeText(this, "Pick at least one image first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            convertImagesToPdf(pickedUris.toList())
        }

        // Initialize Mobile Ads SDK
        MobileAds.initialize(this) {}

        // Load Banner
        val adView = findViewById<AdView>(R.id.adView)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)

        // Load Interstitial
        loadInterstitial()

        // Load Rewarded
        loadRewarded()
    }

    private fun loadInterstitial() {
        val adUnit = "ca-app-pub-6274254207306230/4241332295" // interstitial
        InterstitialAd.load(this, adUnit, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitialAd = ad
                interstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() { interstitialAd = null }
                }
            }
            override fun onAdFailedToLoad(error: LoadAdError) { interstitialAd = null }
        })
    }

    private fun loadRewarded() {
        val adUnit = "ca-app-pub-6274254207306230/9780707239" // rewarded interstitial
        RewardedAd.load(this, adUnit, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                rewardedAd = ad
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                rewardedAd = null
            }
        })
    }

    override fun onBackPressed() {
        // show interstitial if loaded, else normal back
        interstitialAd?.show(this) ?: run { super.onBackPressed() }
    }

    private fun convertImagesToPdf(uris: List<Uri>) {
        statusTv.text = "Creating PDF..."
        Thread {
            var outUri: Uri? = null
            try {
                val pdf = PdfDocument()
                for ((index, uri) in uris.withIndex()) {
                    val bitmap = loadBitmapFromUri(uri) ?: continue
                    val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, index + 1).create()
                    val page = pdf.startPage(pageInfo)
                    page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    pdf.finishPage(page)
                    bitmap.recycle()
                }
                val filename = "converted_${'$'}{System.currentTimeMillis()}.pdf"
                outUri = savePdfToDownloads(pdf, filename)
                pdf.close()

                runOnUiThread {
                    if (outUri != null) {
                        statusTv.text = "Saved: ${'$'}filename"
                        Toast.makeText(this, "PDF saved: ${'$'}filename", Toast.LENGTH_LONG).show()
                        openPdf(outUri)
                    } else {
                        statusTv.text = "Failed to save PDF"
                        Toast.makeText(this, "Failed to save PDF", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("PDF_CONVERT", "error", e)
                runOnUiThread {
                    statusTv.text = "Error: ${'$'}{e.localizedMessage}"
                    Toast.makeText(this, "Error: ${'$'}{e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun loadBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            contentResolver.openInputStream(uri).use { input -> BitmapFactory.decodeStream(input) }
        } catch (e: IOException) {
            null
        }
    }

    private fun savePdfToDownloads(pdf: PdfDocument, filename: String): Uri? {
        val resolver = contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/PDFConverter/")
            }
        }
        val collection =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else MediaStore.Files.getContentUri("external")
        var uri: Uri? = null
        resolver.insert(collection, contentValues)?.let { item ->
            resolver.openOutputStream(item)?.use { out ->
                pdf.writeTo(out)
                out.flush()
                uri = item
            }
        }
        return uri
    }

    private fun openPdf(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (intent.resolveActivity(packageManager) != null) startActivity(intent)
    }
}
